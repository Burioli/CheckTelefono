using System;
using System.Collections.Generic;

public static class Telefono
{

    public static string Check(string[] input)
    {
        return "";
    }
}