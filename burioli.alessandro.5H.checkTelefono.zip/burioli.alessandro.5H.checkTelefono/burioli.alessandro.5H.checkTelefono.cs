using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string[] input1 = { "05417373", "3367726712", "778823" };
        string[] input2 = { "33677267", "33677232", "778823" };
        string[] input3 = { "", "05417723", "+391231231234" };
        string[] input4 = { "3", "05417723", "00391231231230" };

        string output1 = TrovaNumeroTelefono(input1);
        string output2 = TrovaNumeroTelefono(input2);
        string output3 = TrovaNumeroTelefono(input3);
        string output4 = TrovaNumeroTelefono(input4);

        Console.WriteLine(output1);  // Output desiderato: "3367726712"
        Console.WriteLine(output2);  // Output desiderato: ""
        Console.WriteLine(output3);  // Output desiderato: "+391231231234"
        Console.WriteLine(output4);  // Output desiderato: ""
    }

    static string TrovaNumeroTelefono(string[] vettore)
    {
        for (int i = 0; i < vettore.Length; i++)
        {
            if (IsValidNumeroTelefono(vettore[i]))
            {
                return vettore[i];
            }
        }

        // Se nessun numero corrisponde ai criteri, ritorna una stringa vuota
        return "";
    }

    static bool IsValidNumeroTelefono(string numero)
    {
        // Controlla se il numero inizia con +39 ed è lungo 13,
        // oppure inizia con 0039 ed è lungo 14,
        // oppure inizia con 3 ed è lungo 10
        return Regex.IsMatch(numero, @"^(\+39|0039|3)\d{10,13}$");
    }
}
